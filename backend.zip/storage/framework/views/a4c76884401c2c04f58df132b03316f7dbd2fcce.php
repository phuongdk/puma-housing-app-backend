<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('settings')); ?>" method="POST">
    <?php echo e(csrf_field()); ?>


    <div class="row">
        <?php if($user->is_admin): ?>
        <div class="col-lg-6">
            <h3>
                App Settings
            </h3>
            <hr />
            <input type="hidden" id="header_images" name="app_settings_header_images" value="<?php echo e(old('app_settings_header_images', $app_settings->header_images)); ?>" />
            <div class="form-group">
                <label class="control-label">E-Mail</label>
                <input class="form-control" name="app_settings_email" value="<?php echo e(old('app_settings_email', $app_settings->email)); ?>" />
                <?php if($errors->has('app_settings_email')): ?>
                <small class="text-validation-error text-danger"><?php echo e($errors->first('app_settings_email')); ?></small>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label class="control-label">Web Site</label>
                <input class="form-control" name="app_settings_website" value="<?php echo e(old('app_settings_website', $app_settings->website)); ?>" />
                <?php if($errors->has('app_settings_website')): ?>
                <small class="text-validation-error text-danger"><?php echo e($errors->first('app_settings_website')); ?></small>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label class="control-label">App Version</label>
                <input class="form-control" name="app_settings_app_version" value="<?php echo e(old('app_settings_app_version', $app_settings->app_version)); ?>" />
            </div>
            <div class="form-group">
                <label class="control-label">About US</label>
                <textarea class="form-control textarea-editor" name="app_settings_about_us"><?php echo e(old('app_settings_about_us', $app_settings->about_us)); ?></textarea>
            </div>
            <div class="form-group">
                <label class="control-label">Privacy Policy</label>
                <textarea class="form-control textarea-editor" name="app_settings_privacy_policy"><?php echo e(old('app_settings_privacy_policy', $app_settings->privacy_policy)); ?></textarea>
            </div>
            <div class="form-group">
                <label class="control-label">User Terms</label>
                <textarea class="form-control textarea-editor" name="app_settings_user_terms"><?php echo e(old('app_settings_user_terms', $app_settings->user_terms)); ?></textarea>
            </div>
            <div class="form-group">
                <label class="control-label">Application Heading Images</label>
                <input id="inputHeaderImages" type="file" multiple />
            </div>
            <div class="form-group">
                <label class="control-label">Facebook Url</label>
                <input class="form-control" name="app_settings_facebook_url" value="<?php echo e(old('app_settings_facebook_url', $app_settings->facebook_url)); ?>" />
            </div>
            <div class="form-group">
                <label class="control-label">Twitter Url</label>
                <input class="form-control" name="app_settings_twitter_url" value="<?php echo e(old('app_settings_twitter_url', $app_settings->twitter_url)); ?>" />
            </div>
            <div class="form-group">
                <label class="control-label">Youtube Url</label>
                <input class="form-control" name="app_settings_youtube_url" value="<?php echo e(old('app_settings_youtube_url', $app_settings->youtube_url)); ?>" />
            </div>
            <div class="form-group">
                <label class="control-label">Instagram Url</label>
                <input class="form-control" name="app_settings_instagram_url" value="<?php echo e(old('app_settings_instagram_url', $app_settings->instagram_url)); ?>" />
            </div>
        </div>
        <?php endif; ?>

        <div class="col-lg-6">
            <h3>
                User Settings
            </h3>
            <hr />
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label class="control-label">First Name</label>
                        <input class="form-control" name="user_first_name" value="<?php echo e(old('user_first_name', $user->first_name)); ?>" />
                        <?php if($errors->has('user_first_name')): ?>
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('user_first_name')); ?></small>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="control-label">Last Name</label>
                        <input class="form-control" name="user_last_name" value="<?php echo e(old('user_last_name', $user->last_name)); ?>" />
                        <?php if($errors->has('user_last_name')): ?>
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('user_last_name')); ?></small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label class="control-label">Phone Number</label>
                        <input class="form-control" type="tel" name="user_phone_number" value="<?php echo e(old('user_phone_number', $user->phone_number)); ?>" />
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="control-label">Email</label>
                        <input class="form-control" type="email" name="user_email" value="<?php echo e(old('user_email', $user->email)); ?>" />
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('user_email')); ?></small>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label">Username</label>
                <input class="form-control" name="user_username" value="<?php echo e(old('user_username', $user->username)); ?>" />
                <?php if($errors->has('user_username')): ?>
                <small class="text-validation-error text-danger"><?php echo e($errors->first('user_username')); ?></small>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label class="control-label">New Password</label>
                        <input class="form-control" name="user_new_password" type="password" />
                        <?php if($errors->has('user_new_password')): ?>
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('user_new_password')); ?></small>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="control-label">Confirm New Password</label>
                        <input class="form-control" name="user_new_password_again" type="password" />
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label">Address</label>
                <input class="form-control" name="user_address" value="<?php echo e(old('user_address', $user->address)); ?>" />
            </div>
            <div class="row">
                <div class="col-6">
                    <div class="form-group">
                        <label class="control-label">Latitude</label>
                        <input class="form-control" name="user_latitude" value="<?php echo e(old('user_latitude', $user->latitude)); ?>" />
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group">
                        <label class="control-label">Longitude</label>
                        <input class="form-control" name="user_longitude" value="<?php echo e(old('user_longitude', $user->longitude)); ?>" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <input type="submit" value="Save" class="btn btn-primary" />
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('partials.file_pond_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(() => {
        $('.textarea-editor').summernote({
            height: 300
        });
        createFilePond("inputHeaderImages", "header_images");
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\puma-housing-app\backend\resources\views/settings/index.blade.php ENDPATH**/ ?>