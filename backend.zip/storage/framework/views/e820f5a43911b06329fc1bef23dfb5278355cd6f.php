<?php $__env->startSection('content'); ?>

<h1>Create</h1>

<h4>Property</h4>
<hr />
<div class="row">
    <div class="col-xl-12">
        <form action="<?php echo e(route("properties.store")); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" id="image_names" name="image_names" value="<?php echo e(old('image_names')); ?>" />

            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="control-label">Type</label>
                        <select name="property_type_id" class="form-control" required>
                            <?php $__currentLoopData = $property_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == old('property_type_id') ? "selected" : ""); ?>>
                                <?php echo e($item->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('property_type_id')); ?></small>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="control-label">Category</label>
                        <select name="property_category_id" class="form-control" required>
                            <?php $__currentLoopData = $property_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == old('property_category_id') ? "selected" : ""); ?>>
                                <?php echo e($item->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('property_category_id')); ?></small>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="control-label">City</label>
                        <select name="city_id" class="form-control" required>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == old('city_id') ? "selected" : ""); ?>>
                                <?php echo e($item->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('city_id')); ?></small>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="control-label">Agent</label>
                        <?php if(Auth::user()->is_admin): ?>
                        <select name="user_id" class="form-control" required>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == old('user_id') ? "selected" : ""); ?>>
                                <?php echo e($item->first_name . ' ' . $item->last_name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php else: ?>
                        <select name="user_id" class="form-control" disabled required>
                            <option value="<?php echo e(Auth::user()->id); ?>" selected>
                                <?php echo e(Auth::user()->first_name . ' ' . Auth::user()->last_name); ?>

                            </option>
                        </select>
                        <?php endif; ?>
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('user_id')); ?></small>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="control-label">Title</label>
                        <input name="title" class="form-control" value="<?php echo e(old('title')); ?>" required />
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('title')); ?></small>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group form-check mt-4">
                        <label class="form-check-label">
                            <input name="featured" type="checkbox" class="form-check-input" <?php echo e(filter_var(old('featured'), FILTER_VALIDATE_BOOLEAN) ? "checked" : ""); ?> /> Featured
                        </label>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group form-check mt-4">
                        <label class="form-check-label">
                            <input name="visible" type="checkbox" class="form-check-input" <?php echo e(filter_var(old('visible', true), FILTER_VALIDATE_BOOLEAN) ? "checked" : ""); ?> /> Visible
                        </label>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label">Description</label>
                <textarea id="description" name="description" class="form-control textarea-editor"><?php echo e(old('description')); ?></textarea>
                <small class="text-validation-error text-danger"><?php echo e($errors->first('description')); ?></small>
            </div>
            <div class="row">
                <div class="col-sm-3">
                    <div class="form-group">
                        <label class="control-label">Bed Rooms</label>
                        <input name="bed_room_count" type="number" class="form-control" value="<?php echo e(old('bed_room_count')); ?>" required />
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('bed_room_count')); ?></small>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label class="control-label">Bath Rooms</label>
                        <input name="bath_room_count" type="number" class="form-control" value="<?php echo e(old('bath_room_count')); ?>" required />
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('bath_room_count')); ?></small>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label class="control-label">Kitchen Rooms</label>
                        <input name="kitchen_room_count" type="number" class="form-control" value="<?php echo e(old('kitchen_room_count')); ?>" required />
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('kitchen_room_count')); ?></small>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="form-group">
                        <label class="control-label">Parkings</label>
                        <input name="parking_count" type="number" class="form-control" value="<?php echo e(old('parking_count')); ?>" required />
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('parking_count')); ?></small>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 col-md-4 col-lg-2">
                    <div class="form-group">
                        <label class="control-label">Size</label>
                        <input name="size" type="number" class="form-control" value="<?php echo e(old('size')); ?>" required />
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('size')); ?></small>
                    </div>
                </div>
                <div class="col-sm-12 col-md-8 col-lg-10">
                    <div class="form-group">
                        <label class="control-label">Additional Features</label>
                        <input name="additional_features" class="form-control" placeholder="Air Condition, Internet, Example" />
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 col-md-4 col-lg-2">
                    <div class="form-group">
                        <label class="control-label">Currency</label>
                        <select name="currency" class="form-control">
                            <?php $__currentLoopData = array('VNĐ', 'USD'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item); ?>" <?php echo e($item == old('currency') ? "selected" : ""); ?>>
                                <?php echo e($item); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('currency')); ?></small>
                    </div>
                </div>
                <div class="col-sm-12 col-md-8 col-lg-10">
                    <div class="form-group">
                        <label class="control-label">Price</label>
                        <input name="price" type="number" step="1" class="form-control" value="<?php echo e(old('price')); ?>" required />
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('price')); ?></small>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label">Address</label>
                <input name="address" class="form-control" value="<?php echo e(old('address')); ?>" required />
                <small class="text-validation-error text-danger"><?php echo e($errors->first('address')); ?></small>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="control-label">Latitude</label>
                        <input name="latitude" type="number" step="any" class="form-control" value="<?php echo e(old('latitude')); ?>" required />
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('latitude')); ?></small>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <label class="control-label">Longitude</label>
                        <input name="longitude" type="number" step="any" class="form-control" value="<?php echo e(old('longitude')); ?>" required />
                        <small class="text-validation-error text-danger"><?php echo e($errors->first('longitude')); ?></small>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label">Property Images</label>
                <input id="inputPropertyImages" type="file" multiple required />
                <small class="text-validation-error text-danger"><?php echo e($errors->first('image_names')); ?></small>
            </div>
            <div class="form-group">
                <input type="submit" value="Create" class="btn btn-primary" />
            </div>
        </form>
    </div>
</div>

<div>
    <a href="<?php echo e(route('properties.index')); ?>">Back to List</a>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('partials.file_pond_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(() => {
        $('.textarea-editor').summernote({
            height: 300
        });
        createFilePond("inputPropertyImages", "image_names");
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\puma-housing-app\backend\resources\views/properties/create.blade.php ENDPATH**/ ?>