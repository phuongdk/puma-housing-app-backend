<?php $__env->startSection('content'); ?>

<h1>Edit</h1>

<h4>News</h4>
<hr />
<div class="row">
    <div class="col-xl-12">
        <form action="<?php echo e(route('news.update', $news->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo method_field('PUT'); ?>
            <input type="hidden" id="image_name" name="image_name" value="<?php echo e(old('image_name', $news->image_name)); ?>" />
            <div class="form-group">
                <label for="category_id" class="control-label">Category</label>
                <select name="category_id" class="form-control">
                    <?php $__currentLoopData = $news_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == old('category_id', $news->category_id) ? "selected" : ""); ?>>
                        <?php echo e($item->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <small class="text-validation-error text-danger"><?php echo e($errors->first('category_id')); ?></small>
            </div>
            <div class="form-group">
                <label class="control-label">Title</label>
                <input name="title" class="form-control" value="<?php echo e(old('title', $news->title)); ?>" required />
                <small class="text-validation-error text-danger"><?php echo e($errors->first('title')); ?></small>
            </div>
            <div class="form-group">
                <label class="control-label">Content</label>
                <textarea name="content" class="form-control textarea-editor"><?php echo e(old('content', $news->content)); ?></textarea>
                <small class="text-validation-error text-danger"><?php echo e($errors->first('content')); ?></small>
            </div>
            <div class="form-group">
                <label class="control-label">News Photo</label>
                <input id="imageFile" type="file" required />
                <small class="text-validation-error text-danger"><?php echo e($errors->first('image_name')); ?></small>
            </div>
            <div class="form-group">
                <input type="submit" value="Save" class="btn btn-primary" />
            </div>
        </form>
    </div>
</div>

<div>
    <a href="<?php echo e(route('news.index')); ?>">Back to List</a>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('partials.file_pond_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(() => {
        $('.textarea-editor').summernote({
            height: 300
        });
        createFilePond("imageFile", "image_name");
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\puma-housing-app\backend\resources\views/news/edit.blade.php ENDPATH**/ ?>