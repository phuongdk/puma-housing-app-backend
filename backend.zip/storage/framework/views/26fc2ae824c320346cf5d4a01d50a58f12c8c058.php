<?php $__env->startSection('content'); ?>

<h1 class="mt-2">Welcome, <?php echo e(Auth::user()->first_name . ' ' . Auth::user()->last_name); ?></h1>

<div class="row">
    <div class="col-lg-12 col-xl-6">
        <div class="card mt-3">
            <div class="card-body">
                <h5 class="card-title">Properties trending</h5>

                <table id="likedPropertiesTable" class="table table-striped">
                    <thead>
                        <tr>
                            <th>
                                Title
                            </th>
                            <th>
                                City
                            </th>
                            <th>
                                Likes
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $topList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($item->property_title); ?>

                            </td>
                            <td>
                                <?php echo e($item->city_name); ?>

                            </td>
                            <td>
                                <?php echo e($item->count); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\puma-housing-app\backend\resources\views/dashboard/index.blade.php ENDPATH**/ ?>