<?php $__env->startSection('content'); ?>

<div class="d-flex flex-row align-items-center">
    <h3>
        News Categories
    </h3>
    <a class="btn btn-info btn-sm ml-auto" href="<?php echo e(route('news_categories.create')); ?>">Create News Category</a>
</div>

<hr />

<table id="newsCategoriesTable" class="table table-striped">
    <thead>
        <tr>
            <th>
                Name
            </th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $newsCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($item->name); ?>

            </td>
            <td>
                <a href="<?php echo e(route('news_categories.edit', $item->id)); ?>" class="btn btn-info btn-sm"><span data-feather="edit-2"></span></a>
                <a href="javascript:void(0);" data-entity-id="<?php echo e($item->id); ?>" class="btn btn-danger btn-sm delete-btn"><span data-feather="trash-2"></span></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo $__env->make('partials.delete_confirm_modal', ['actionName' => 'news_categories'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        createTable("#newsCategoriesTable");
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\puma-housing-app\backend\resources\views/news_categories/index.blade.php ENDPATH**/ ?>