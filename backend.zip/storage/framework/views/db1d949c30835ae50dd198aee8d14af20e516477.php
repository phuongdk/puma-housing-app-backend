<!-- Modal -->
<div class="modal fade" id="delete_confirm_modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
        <form id="delete_confirm_form" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo method_field('DELETE'); ?>
            <div class="modal-body">
                <input type="hidden" id="delete_confirm_entity_id" />
                Bạn có chắc không?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-dismiss="modal">CANCEL</button>
                <button type="submit" class="btn btn-danger">DELETE</button>
            </div>
        </form>
    </div>
    </div>
</div>
<!-- EndModal -->

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $(".table").on('click', '.delete-btn', function () {
            const entityId = $(this).data('entity-id');
            $("#delete_confirm_entity_id").val(entityId);
            $("#delete_confirm_form").attr('action', '/<?php echo e($actionName); ?>/' + entityId);
            $("#delete_confirm_modal").modal('show');
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\Administrator\Desktop\puma-housing-app\backend\resources\views/partials/delete_confirm_modal.blade.php ENDPATH**/ ?>