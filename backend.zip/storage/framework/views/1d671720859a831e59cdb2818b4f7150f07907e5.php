<?php $__env->startSection('content'); ?>

<div class="d-flex flex-row align-items-center">
    <h3>
        Users
    </h3>
</div>

<hr />

<table id="usersTable" class="table table-striped">
    <thead>
        <tr>
            <th>
                FirstName
            </th>
            <th>
                LastName
            </th>
            <th>
                PhoneNumber
            </th>
            <th>
                Email
            </th>
            <th>
                Username
            </th>
            <th>
                IsAdmin
            </th>
            <th>
                IsAgent
            </th>
            <th>
                Address
            </th>
            <th>
            </th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($item->first_name); ?>

            </td>
            <td>
                <?php echo e($item->last_name); ?>

            </td>
            <td>
                <?php echo e($item->phone_number); ?>

            </td>
            <td>
                <?php echo e($item->email); ?>

            </td>
            <td>
                <?php echo e($item->username); ?>

            </td>
            <td>
                <input type="checkbox" <?php echo e(Auth::user()->id == $item->id ? 'disabled' : ''); ?> <?php echo e($item->is_admin ? 'checked' : ''); ?> onclick="handleChecked('admin', this, <?php echo e($item->id); ?>);" />
            </td>
            <td>
                <input type="checkbox" <?php echo e($item->is_agent ? 'checked' : ''); ?> onclick="handleChecked('agent', this, <?php echo e($item->id); ?>);" />
            </td>
            <td>
                <?php echo e($item->address); ?>

            </td>
            <td>
                <a href="<?php echo e(route('users.edit', $item->id)); ?>" class="btn btn-info btn-sm"><span data-feather="edit-2"></span></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        createTable("#usersTable");
    });

    function handleChecked(role, cb, id) {

        $.ajax({
            type: "POST",
            url: "/users/update_role",
            headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'},
            dataType: 'json',
            data: {
                role: role,
                userId: id,
                isChecked: cb.checked
            },
            success: () => {}
        })
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\puma-housing-app\backend\resources\views/users/index.blade.php ENDPATH**/ ?>