<?php $__env->startSection('content'); ?>

<h1>Edit</h1>

<h4>Property Category</h4>
<hr />
<div class="row">
    <div class="col-md-4">
        <form action="<?php echo e(route('property_categories.update', $propertyCategory->id)); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label class="control-label">Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $propertyCategory->name)); ?>" required />
                <small class="text-validation-error text-danger"><?php echo e($errors->first('name')); ?></small>
            </div>
            <div class="form-group">
                <input type="submit" value="Save" class="btn btn-primary" />
            </div>
        </form>
    </div>
</div>

<div>
    <a href="<?php echo e(route('property_categories.index')); ?>">Back to List</a>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\puma-housing-app\backend\resources\views/property_categories/edit.blade.php ENDPATH**/ ?>