<?php $__env->startSection('content'); ?>

<form class="form-signin" method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <img class="mb-3" src="/logo.png" alt="" width="300">
    <h1 class="h4 mb-4 font-weight-normal">Please sign in</h1>

    <label for="username" class="sr-only">Username</label>
    <input id="username" name="username" type="text" class="form-control" placeholder="Username" required autofocus />

    <label for="password" class="sr-only">Password</label>
    <input id="password" name="password" type="password" class="form-control" placeholder="Password" required />

    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <label class="text-danger"><?php echo e($message); ?></label>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <label class="text-danger"><?php echo e($message); ?></label>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <button class="btn btn-lg btn-primary btn-block mt-4" type="submit">Sign in</button>
    <div class="mt-3">
        <a class="forget-btn" href="<?php echo e(route('password.request')); ?>">Forget Password</a>
    </div>

    <p class="mt-3 mb-3 text-muted">&copy; 2020 Puma Housing made by Phuongdk</p>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\puma-housing-app\backend\resources\views/auth/login.blade.php ENDPATH**/ ?>