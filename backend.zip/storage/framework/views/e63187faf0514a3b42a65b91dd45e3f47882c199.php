<?php $__env->startSection('content'); ?>

<h1>Create</h1>

<h4>City</h4>
<hr />
<div class="row">
    <div class="col-md-12">
        <form action="<?php echo e(route("cities.store")); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" id="image_name" name="image_name" />
            <div class="form-group">
                <label class="control-label">Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required />
                <small class="text-validation-error text-danger"><?php echo e($errors->first('name')); ?></small>
            </div>
            <div class="form-group">
                <label class="control-label">City Image</label>
                <input id="imageFile" type="file" required />
                <small class="text-validation-error text-danger"><?php echo e($errors->first('image_name')); ?></small>
            </div>
            <div class="form-group">
                <input type="submit" value="Create" class="btn btn-primary" />
            </div>
        </form>
    </div>
</div>

<div>
    <a href="<?php echo e(route('cities.index')); ?>">Back to List</a>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('partials.file_pond_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    $(document).ready(() => {
        createFilePond("imageFile", "image_name");
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\puma-housing-app\backend\resources\views/cities/create.blade.php ENDPATH**/ ?>